const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const { exec } = require('child_process');
const os = require('os');
const path = require('path');

const app = express();
const JWT_SECRET = process.env.JWT_SECRET || 'hotspot-monitor-secret-key-2024';
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';

// Middleware
app.use(cors({
    origin: true,
    credentials: true
}));
app.use(express.json());
app.use(cookieParser());
app.use(express.static('public'));

// ============ DATA STORE ============
let connectedDevices = [];
let deviceLogs = [];
let scanHistory = [];
let isScanning = false;
let adminSettings = {
    autoScan: true,
    scanInterval: 30,
    defaultDataLimit: 5,
    notifyOnConnect: true,
    notifyOnDisconnect: true,
    notifyOnLimit: true
};

// ============ AUTH MIDDLEWARE ============
function authMiddleware(req, res, next) {
    const token = req.cookies.token || req.headers.authorization?.split(' ')[1];
    
    if (!token) {
        return res.status(401).json({ error: 'Unauthorized - No token' });
    }
    
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    } catch (error) {
        return res.status(401).json({ error: 'Unauthorized - Invalid token' });
    }
}

// ============ AUTH ROUTES ============

// Login
app.post('/api/auth/login', async (req, res) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ error: 'Username dan password diperlukan' });
    }
    
    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
        const token = jwt.sign(
            { username, role: 'admin' },
            JWT_SECRET,
            { expiresIn: '24h' }
        );
        
        res.cookie('token', token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            maxAge: 24 * 60 * 60 * 1000 // 24 hours
        });
        
        return res.json({
            success: true,
            token,
            user: { username, role: 'admin' }
        });
    }
    
    res.status(401).json({ error: 'Username atau password salah' });
});

// Logout
app.post('/api/auth/logout', (req, res) => {
    res.clearCookie('token');
    res.json({ success: true });
});

// Check auth status
app.get('/api/auth/status', (req, res) => {
    const token = req.cookies.token;
    if (!token) {
        return res.json({ authenticated: false });
    }
    
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        res.json({ 
            authenticated: true, 
            user: decoded 
        });
    } catch (error) {
        res.json({ authenticated: false });
    }
});

// Change password
app.post('/api/auth/change-password', authMiddleware, async (req, res) => {
    const { oldPassword, newPassword } = req.body;
    
    if (oldPassword !== ADMIN_PASSWORD) {
        return res.status(400).json({ error: 'Password lama salah' });
    }
    
    if (newPassword.length < 6) {
        return res.status(400).json({ error: 'Password minimal 6 karakter' });
    }
    
    // In production, update environment variable or database
    // For demo, just return success
    res.json({ 
        success: true, 
        message: 'Password berhasil diubah (simulasi)' 
    });
});

// ============ NETWORK FUNCTIONS ============

function getNetworkInfo() {
    const interfaces = os.networkInterfaces();
    let networkInfo = {
        ip: '0.0.0.0',
        subnet: '255.255.255.0',
        network: '192.168.1.0'
    };

    for (const iface of Object.values(interfaces)) {
        for (const details of iface) {
            if (details.family === 'IPv4' && !details.internal) {
                networkInfo.ip = details.address;
                const ipParts = details.address.split('.');
                networkInfo.network = `${ipParts[0]}.${ipParts[1]}.${ipParts[2]}.0`;
                break;
            }
        }
    }
    return networkInfo;
}

function scanNetwork() {
    return new Promise((resolve) => {
        const networkInfo = getNetworkInfo();
        const networkBase = networkInfo.network.replace('.0', '');
        const devices = [];
        let completed = 0;
        const total = 254;
        
        const skipIPs = ['127.0.0.1', '0.0.0.0', `${networkBase}.1`];
        
        for (let i = 1; i <= 254; i++) {
            const ip = `${networkBase}.${i}`;
            
            if (skipIPs.includes(ip)) {
                completed++;
                continue;
            }
            
            exec(`ping -c 1 -W 1 ${ip}`, (error) => {
                if (!error) {
                    exec(`arp -a ${ip}`, (arpErr, arpOut) => {
                        let mac = 'N/A';
                        const macMatch = arpOut.match(/([a-fA-F0-9]{2}[:-][a-fA-F0-9]{2}[:-][a-fA-F0-9]{2}[:-][a-fA-F0-9]{2}[:-][a-fA-F0-9]{2}[:-][a-fA-F0-9]{2})/i);
                        if (macMatch) {
                            mac = macMatch[1].toUpperCase();
                        }
                        devices.push({ ip, mac, status: 'online' });
                        completed++;
                        if (completed >= total) resolve(devices);
                    });
                } else {
                    completed++;
                    if (completed >= total) resolve(devices);
                }
            });
        }
        
        setTimeout(() => resolve(devices), 60000);
    });
}

function getVendor(mac) {
    const vendors = {
        '00:11:22': 'Apple',
        '00:1A:2B': 'Samsung',
        '00:50:56': 'VMware',
        '00:1C:42': 'HP',
        '00:0C:29': 'VMware',
        '00:15:5D': 'Microsoft',
        '00:1B:21': 'Dell',
        '00:1E:4F': 'Dell',
        '00:1F:16': 'Lenovo',
        '00:23:32': 'Apple',
        '00:24:36': 'Samsung',
        '00:25:00': 'Apple',
        '00:26:BB': 'Huawei',
        '00:27:0E': 'Xiaomi',
        '00:28:0F': 'Oppo',
        '00:29:10': 'Vivo',
        '00:2A:11': 'Realme',
        '00:2B:12': 'OnePlus',
        '00:2C:13': 'Google',
        '00:2D:14': 'Motorola',
        '00:2E:15': 'Sony',
        '00:2F:16': 'LG',
        '00:30:17': 'Nokia',
        '00:31:18': 'Asus'
    };
    
    if (!mac || mac === 'N/A') return 'Unknown';
    const prefix = mac.slice(0, 8).toUpperCase();
    return vendors[prefix] || 'Unknown';
}

async function performScan() {
    if (isScanning) return { success: false, message: 'Scan in progress' };
    isScanning = true;
    
    try {
        const devices = await scanNetwork();
        const now = Date.now();
        let newDevices = 0;
        
        for (const device of devices) {
            const existing = connectedDevices.find(d => d.ip === device.ip);
            const vendor = getVendor(device.mac);
            
            if (existing) {
                const wasOffline = existing.status === 'offline';
                existing.lastSeen = now;
                existing.status = 'online';
                existing.mac = device.mac;
                existing.vendor = vendor;
                if (!existing.firstSeen) existing.firstSeen = now;
                
                if (wasOffline && adminSettings.notifyOnConnect) {
                    deviceLogs.unshift({
                        time: new Date().toISOString(),
                        message: `🟢 ${existing.hostname || existing.ip} kembali online`,
                        type: 'connection'
                    });
                }
            } else {
                let hostname = device.ip;
                try {
                    const { stdout } = await new Promise((resolve, reject) => {
                        exec(`nslookup ${device.ip}`, (error, stdout) => {
                            if (error) reject(error);
                            else resolve({ stdout });
                        });
                    });
                    const match = stdout.match(/Name:\s+(\S+)/);
                    if (match) hostname = match[1];
                } catch (e) {}
                
                const newDevice = {
                    id: Date.now() + Math.random() * 1000,
                    ip: device.ip,
                    mac: device.mac,
                    vendor: vendor,
                    hostname: hostname !== device.ip ? hostname : null,
                    status: 'online',
                    firstSeen: now,
                    lastSeen: now,
                    dataUsed: 0,
                    dataLimit: adminSettings.defaultDataLimit,
                    notes: ''
                };
                connectedDevices.push(newDevice);
                newDevices++;
                
                if (adminSettings.notifyOnConnect) {
                    deviceLogs.unshift({
                        time: new Date().toISOString(),
                        message: `📱 Device baru: ${hostname} (${device.ip})`,
                        type: 'connection'
                    });
                }
            }
        }
        
        // Check offline devices
        const timeout = 120000;
        for (const device of connectedDevices) {
            if (device.status === 'online' && (now - device.lastSeen) > timeout) {
                device.status = 'offline';
                if (adminSettings.notifyOnDisconnect) {
                    deviceLogs.unshift({
                        time: new Date().toISOString(),
                        message: `🔴 ${device.hostname || device.ip} offline`,
                        type: 'connection'
                    });
                }
            }
        }
        
        if (deviceLogs.length > 500) {
            deviceLogs = deviceLogs.slice(0, 500);
        }
        
        isScanning = false;
        return { 
            success: true, 
            total: connectedDevices.length,
            online: connectedDevices.filter(d => d.status === 'online').length,
            newDevices
        };
        
    } catch (error) {
        console.error('Scan error:', error);
        isScanning = false;
        return { success: false, error: error.message };
    }
}

// ============ PROTECTED API ROUTES ============

// Get all devices
app.get('/api/devices', authMiddleware, (req, res) => {
    res.json({
        devices: connectedDevices,
        online: connectedDevices.filter(d => d.status === 'online').length,
        total: connectedDevices.length,
        lastScan: scanHistory.length > 0 ? scanHistory[scanHistory.length - 1].time : null
    });
});

// Get device by IP
app.get('/api/device/:ip', authMiddleware, (req, res) => {
    const device = connectedDevices.find(d => d.ip === req.params.ip);
    if (device) {
        res.json(device);
    } else {
        res.status(404).json({ error: 'Device not found' });
    }
});

// Update device
app.put('/api/device/:id', authMiddleware, (req, res) => {
    const device = connectedDevices.find(d => d.id === parseInt(req.params.id));
    if (!device) {
        return res.status(404).json({ error: 'Device not found' });
    }
    
    const { name, dataLimit, notes } = req.body;
    if (name) device.hostname = name;
    if (dataLimit) device.dataLimit = parseFloat(dataLimit);
    if (notes !== undefined) device.notes = notes;
    
    deviceLogs.unshift({
        time: new Date().toISOString(),
        message: `✏️ ${device.hostname || device.ip} diperbarui`,
        type: 'system'
    });
    
    res.json({ success: true, device });
});

// Update device data usage
app.post('/api/device/:id/data', authMiddleware, (req, res) => {
    const device = connectedDevices.find(d => d.id === parseInt(req.params.id));
    if (!device) {
        return res.status(404).json({ error: 'Device not found' });
    }
    
    const { dataUsed } = req.body;
    if (dataUsed !== undefined) {
        device.dataUsed = parseFloat(dataUsed);
        
        if (device.dataUsed >= device.dataLimit && adminSettings.notifyOnLimit) {
            deviceLogs.unshift({
                time: new Date().toISOString(),
                message: `⚠️ ${device.hostname || device.ip} mencapai batas data (${device.dataLimit}GB)`,
                type: 'warning'
            });
        }
        
        deviceLogs.unshift({
            time: new Date().toISOString(),
            message: `📊 ${device.hostname || device.ip} menggunakan ${dataUsed}GB data`,
            type: 'data'
        });
        
        res.json({ success: true, device });
    } else {
        res.status(400).json({ error: 'dataUsed required' });
    }
});

// Delete device
app.delete('/api/device/:id', authMiddleware, (req, res) => {
    const index = connectedDevices.findIndex(d => d.id === parseInt(req.params.id));
    if (index === -1) {
        return res.status(404).json({ error: 'Device not found' });
    }
    
    const device = connectedDevices[index];
    connectedDevices.splice(index, 1);
    
    deviceLogs.unshift({
        time: new Date().toISOString(),
        message: `🗑️ ${device.hostname || device.ip} dihapus`,
        type: 'system'
    });
    
    res.json({ success: true });
});

// Get logs
app.get('/api/logs', authMiddleware, (req, res) => {
    const limit = parseInt(req.query.limit) || 50;
    const type = req.query.type;
    let logs = deviceLogs;
    
    if (type && type !== 'all') {
        logs = logs.filter(l => l.type === type);
    }
    
    res.json(logs.slice(0, limit));
});

// Get statistics
app.get('/api/stats', authMiddleware, (req, res) => {
    const online = connectedDevices.filter(d => d.status === 'online');
    const offline = connectedDevices.filter(d => d.status === 'offline');
    const totalData = connectedDevices.reduce((sum, d) => sum + (d.dataUsed || 0), 0);
    
    // Calculate uptime
    let totalUptime = 0;
    let uptimeCount = 0;
    for (const device of connectedDevices) {
        if (device.status === 'online' && device.firstSeen) {
            totalUptime += (Date.now() - device.firstSeen) / 60000;
            uptimeCount++;
        }
    }
    
    res.json({
        total: connectedDevices.length,
        online: online.length,
        offline: offline.length,
        totalDataUsed: totalData,
        averageData: connectedDevices.length > 0 ? totalData / connectedDevices.length : 0,
        averageUptime: uptimeCount > 0 ? totalUptime / uptimeCount : 0,
        topUsers: [...connectedDevices]
            .sort((a, b) => (b.dataUsed || 0) - (a.dataUsed || 0))
            .slice(0, 5)
            .map(d => ({ name: d.hostname || d.ip, data: d.dataUsed || 0 }))
    });
});

// Scan now
app.post('/api/scan', authMiddleware, async (req, res) => {
    const result = await performScan();
    if (result.success) {
        scanHistory.push({
            time: Date.now(),
            total: result.total,
            online: result.online
        });
    }
    res.json(result);
});

// Get network info
app.get('/api/network', authMiddleware, (req, res) => {
    res.json(getNetworkInfo());
});

// Get settings
app.get('/api/settings', authMiddleware, (req, res) => {
    res.json(adminSettings);
});

// Update settings
app.put('/api/settings', authMiddleware, (req, res) => {
    const { autoScan, scanInterval, defaultDataLimit, notifyOnConnect, notifyOnDisconnect, notifyOnLimit } = req.body;
    
    if (autoScan !== undefined) adminSettings.autoScan = autoScan;
    if (scanInterval !== undefined) adminSettings.scanInterval = scanInterval;
    if (defaultDataLimit !== undefined) adminSettings.defaultDataLimit = defaultDataLimit;
    if (notifyOnConnect !== undefined) adminSettings.notifyOnConnect = notifyOnConnect;
    if (notifyOnDisconnect !== undefined) adminSettings.notifyOnDisconnect = notifyOnDisconnect;
    if (notifyOnLimit !== undefined) adminSettings.notifyOnLimit = notifyOnLimit;
    
    deviceLogs.unshift({
        time: new Date().toISOString(),
        message: `⚙️ Pengaturan diperbarui`,
        type: 'system'
    });
    
    res.json({ success: true, settings: adminSettings });
});

// Export data
app.get('/api/export', authMiddleware, (req, res) => {
    const data = {
        exportedAt: new Date().toISOString(),
        devices: connectedDevices,
        logs: deviceLogs,
        history: scanHistory,
        settings: adminSettings
    };
    res.json(data);
});

// Clear data
app.post('/api/clear', authMiddleware, (req, res) => {
    connectedDevices = [];
    deviceLogs = [];
    scanHistory = [];
    res.json({ success: true });
});

// ============ AUTO SCAN ============
let autoScanTimer = null;

function startAutoScan() {
    if (autoScanTimer) {
        clearInterval(autoScanTimer);
        autoScanTimer = null;
    }
    
    if (adminSettings.autoScan) {
        // Initial scan after 3 seconds
        setTimeout(() => {
            performScan();
        }, 3000);
        
        autoScanTimer = setInterval(() => {
            performScan();
        }, adminSettings.scanInterval * 1000);
    }
}

// ============ SERVER ============
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`\n🚀 Hotspot Monitor Pro Server running at:`);
    console.log(`   http://localhost:${PORT}`);
    console.log(`   http://${getNetworkInfo().ip}:${PORT}\n`);
    console.log('🔐 Default Login:');
    console.log(`   Username: ${ADMIN_USERNAME}`);
    console.log(`   Password: ${ADMIN_PASSWORD}\n`);
    startAutoScan();
});

process.on('SIGINT', () => {
    if (autoScanTimer) {
        clearInterval(autoScanTimer);
    }
    console.log('\n👋 Server stopped');
    process.exit();
});

module.exports = app;