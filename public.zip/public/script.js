// ============ CONFIG ============
const API_URL = '/api';
let currentPage = 'dashboard';
let editDeviceId = null;
let updateInterval = null;

// ============ AUTH ============
async function checkAuth() {
    try {
        const response = await fetch(`${API_URL}/auth/status`);
        const data = await response.json();
        if (!data.authenticated) {
            window.location.href = '/';
        }
        return data;
    } catch (error) {
        window.location.href = '/';
    }
}

async function logout() {
    try {
        await fetch(`${API_URL}/auth/logout`, { method: 'POST' });
        window.location.href = '/';
    } catch (error) {
        showToast('Gagal logout', 'error');
    }
}

// ============ SIDEBAR ============
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
}

document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', function(e) {
        e.preventDefault();
        const page = this.dataset.page;
        switchPage(page);
    });
});

function switchPage(page) {
    currentPage = page;
    
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.querySelector(`[data-page="${page}"]`)?.classList.add('active');
    
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById(`page-${page}`)?.classList.add('active');
    
    const titles = {
        dashboard: 'Dashboard',
        devices: 'Perangkat',
        logs: 'Logs',
        settings: 'Pengaturan'
    };
    document.getElementById('pageTitle').textContent = titles[page] || page;
    
    // Close sidebar on mobile
    if (window.innerWidth <= 768) {
        document.getElementById('sidebar').classList.remove('open');
    }
    
    // Refresh content
    if (page === 'dashboard') refreshDashboard();
    if (page === 'devices') fetchDevices();
    if (page === 'logs') fetchLogs();
    if (page === 'settings') loadSettings();
}

// ============ TOAST ============
function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    const icons = {
        success: '✅',
        error: '❌',
        warning: '⚠️',
        info: 'ℹ️'
    };
    
    toast.innerHTML = `${icons[type] || '📢'} ${message}`;
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('hide');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// ============ MODAL ============
function openModal(id) {
    document.getElementById(id).classList.add('show');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('show');
}

// Close modal on outside click
document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) {
            this.classList.remove('show');
        }
    });
});

// ============ DASHBOARD ============
async function refreshDashboard() {
    try {
        const stats = await fetchStats();
        if (stats) {
            document.getElementById('totalDevices').textContent = stats.total || 0;
            document.getElementById('onlineDevices').textContent = stats.online || 0;
            document.getElementById('offlineDevices').textContent = stats.offline || 0;
            document.getElementById('totalData').textContent = (stats.totalDataUsed || 0).toFixed(1) + ' GB';
            document.getElementById('avgUptime').textContent = Math.round(stats.averageUptime || 0) + 'm';
            document.getElementById('avgData').textContent = ((stats.averageData || 0) * 1000).toFixed(0) + ' MB';
        }
        
        await fetchDevices();
        await fetchLogs();
        renderTopUsers();
        renderStatusDonut();
        renderRecentActivity();
        
        document.getElementById('lastUpdate').textContent = 'Last update: ' + new Date().toLocaleTimeString('id-ID');
    } catch (error) {
        console.error('Dashboard error:', error);
    }
}

// ============ STATS ============
async function fetchStats() {
    try {
        const response = await fetch(`${API_URL}/stats`);
        return await response.json();
    } catch (error) {
        console.error('Error fetching stats:', error);
        return null;
    }
}

// ============ DEVICES ============
async function fetchDevices() {
    try {
        const response = await fetch(`${API_URL}/devices`);
        const data = await response.json();
        renderDevices(data.devices || []);
        updateConnectionStatus(data.online > 0);
        return data;
    } catch (error) {
        console.error('Error fetching devices:', error);
        return null;
    }
}

function renderDevices(devices) {
    const tbody = document.getElementById('devicesTableBody');
    
    if (!devices || devices.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" class="empty-state">
                    <span class="material-icons">devices_off</span>
                    Tidak ada perangkat terdeteksi
                </td>
            </tr>
        `;
        return;
    }
    
    // Apply filters
    const search = document.getElementById('deviceSearch')?.value.toLowerCase() || '';
    const statusFilter = document.getElementById('statusFilter')?.value || 'all';
    
    let filtered = devices;
    if (search) {
        filtered = filtered.filter(d => 
            d.ip.includes(search) || 
            (d.hostname && d.hostname.toLowerCase().includes(search)) ||
            (d.vendor && d.vendor.toLowerCase().includes(search))
        );
    }
    if (statusFilter !== 'all') {
        filtered = filtered.filter(d => d.status === statusFilter);
    }
    
    // Sort: online first
    filtered.sort((a, b) => {
        if (a.status === 'online' && b.status !== 'online') return -1;
        if (a.status !== 'online' && b.status === 'online') return 1;
        return a.ip.localeCompare(b.ip);
    });
    
    tbody.innerHTML = filtered.map((device, index) => {
        const statusClass = device.status === 'online' ? 'online' : 'offline';
        const statusLabel = device.status === 'online' ? 'Online' : 'Offline';
        
        return `
            <tr>
                <td>${index + 1}</td>
                <td><strong>${device.ip}</strong></td>
                <td>${device.hostname || '-'}</td>
                <td>${device.vendor || 'Unknown'}</td>
                <td><span class="status-badge ${statusClass}">${statusLabel}</span></td>
                <td>${(device.dataUsed || 0).toFixed(1)} GB</td>
                <td>${device.dataLimit || 5} GB</td>
                <td>
                    <button class="btn btn-primary btn-sm" onclick="openEditModal(${device.id})">
                        <span class="material-icons">edit</span>
                    </button>
                    <button class="btn btn-danger btn-sm" onclick="deleteDevice(${device.id})">
                        <span class="material-icons">delete</span>
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

function filterDevices() {
    fetchDevices();
}

// ============ EDIT DEVICE ============
function openEditModal(id) {
    editDeviceId = id;
    // Fetch device details
    fetch(`${API_URL}/devices`)
        .then(res => res.json())
        .then(data => {
            const device = data.devices.find(d => d.id === id);
            if (device) {
                document.getElementById('editHostname').value = device.hostname || '';
                document.getElementById('editLimit').value = device.dataLimit || 5;
                document.getElementById('editNotes').value = device.notes || '';
                openModal('editModal');
            }
        });
}

function saveEdit() {
    const data = {
        name: document.getElementById('editHostname').value,
        dataLimit: parseFloat(document.getElementById('editLimit').value) || 5,
        notes: document.getElementById('editNotes').value
    };
    
    fetch(`${API_URL}/device/${editDeviceId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(result => {
        if (result.success) {
            showToast('Device berhasil diupdate!');
            closeModal('editModal');
            fetchDevices();
            refreshDashboard();
        } else {
            showToast('Gagal update device', 'error');
        }
    })
    .catch(() => showToast('Gagal update device', 'error'));
}

function deleteDevice(id) {
    if (!confirm('Yakin ingin menghapus device ini?')) return;
    
    fetch(`${API_URL}/device/${id}`, {
        method: 'DELETE'
    })
    .then(res => res.json())
    .then(result => {
        if (result.success) {
            showToast('Device berhasil dihapus!');
            fetchDevices();
            refreshDashboard();
        } else {
            showToast('Gagal hapus device', 'error');
        }
    })
    .catch(() => showToast('Gagal hapus device', 'error'));
}

// ============ TOP USERS CHART ============
async function renderTopUsers() {
    const container = document.getElementById('topUsersChart');
    try {
        const stats = await fetchStats();
        const users = stats?.topUsers || [];
        
        if (users.length === 0) {
            container.innerHTML = '<div class="empty-state">Belum ada data</div>';
            return;
        }
        
        const maxData = Math.max(...users.map(u => u.data), 1);
        const colors = ['#6366f1', '#8b5cf6', '#a855f7', '#d946ef', '#ec4899'];
        
        container.innerHTML = users.map((user, index) => {
            const percent = (user.data / maxData) * 100;
            return `
                <div class="chart-bar-item">
                    <div class="chart-bar-label">${user.name}</div>
                    <div class="chart-bar-track">
                        <div class="chart-bar-fill" style="width: ${percent}%; background: ${colors[index % colors.length]}">
                            ${user.data.toFixed(1)} GB
                        </div>
                    </div>
                    <div class="chart-bar-value">${Math.round(percent)}%</div>
                </div>
            `;
        }).join('');
    } catch (error) {
        container.innerHTML = '<div class="empty-state">Error loading chart</div>';
    }
}

// ============ STATUS DONUT ============
async function renderStatusDonut() {
    const container = document.getElementById('statusDonut');
    try {
        const stats = await fetchStats();
        const online = stats?.online || 0;
        const offline = stats?.offline || 0;
        const total = stats?.total || 1;
        
        const onlineDeg = (online / total) * 360;
        const offlineDeg = (offline / total) * 360;
        
        container.innerHTML = `
            <div class="donut-container">
                <div class="donut" style="background: conic-gradient(
                    #22c55e 0deg ${onlineDeg}deg,
                    #ef4444 ${onlineDeg}deg ${onlineDeg + offlineDeg}deg,
                    #e2e8f0 ${onlineDeg + offlineDeg}deg 360deg
                )">
                    <div class="donut-center">
                        ${online}
                        <small>Online</small>
                    </div>
                </div>
                <div class="donut-legend">
                    <div class="legend-item">
                        <div class="legend-color" style="background: #22c55e;"></div>
                        Online: ${online}
                    </div>
                    <div class="legend-item">
                        <div class="legend-color" style="background: #ef4444;"></div>
                        Offline: ${offline}
                    </div>
                    <div class="legend-item">
                        <div class="legend-color" style="background: #e2e8f0;"></div>
                        Total: ${total}
                    </div>
                </div>
            </div>
        `;
    } catch (error) {
        container.innerHTML = '<div class="empty-state">Error loading chart</div>';
    }
}

// ============ RECENT ACTIVITY ============
async function renderRecentActivity() {
    const container = document.getElementById('recentActivity');
    try {
        const response = await fetch(`${API_URL}/logs?limit=10`);
        const logs = await response.json();
        
        if (!logs || logs.length === 0) {
            container.innerHTML = '<div class="empty-state">Belum ada aktivitas</div>';
            return;
        }
        
        container.innerHTML = logs.map(log => {
            const time = new Date(log.time).toLocaleTimeString('id-ID');
            return `
                <div class="log-entry">
                    <span class="log-time">${time}</span>
                    <span class="log-badge ${log.type}">${log.type}</span>
                    <span>${log.message}</span>
                </div>
            `;
        }).join('');
    } catch (error) {
        container.innerHTML = '<div class="empty-state">Error loading activity</div>';
    }
}

// ============ LOGS ============
async function fetchLogs() {
    try {
        const type = document.getElementById('logFilter')?.value || 'all';
        const url = type !== 'all' ? `${API_URL}/logs?type=${type}` : `${API_URL}/logs`;
        const response = await fetch(url);
        const logs = await response.json();
        renderLogs(logs);
    } catch (error) {
        console.error('Error fetching logs:', error);
    }
}

function renderLogs(logs) {
    const container = document.getElementById('logsContainer');
    
    if (!logs || logs.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <span class="material-icons">history</span>
                Belum ada log
            </div>
        `;
        return;
    }
    
    container.innerHTML = logs.map(log => {
        const time = new Date(log.time).toLocaleString('id-ID');
        return `
            <div class="log-entry">
                <span class="log-time">${time}</span>
                <span class="log-badge ${log.type}">${log.type}</span>
                <span>${log.message}</span>
            </div>
        `;
    }).join('');
}

function filterLogs() {
    fetchLogs();
}

function clearLogs() {
    if (!confirm('Yakin ingin menghapus semua log?')) return;
    // Implementation would need server-side clear logs endpoint
    showToast('Log berhasil dihapus!', 'info');
    fetchLogs();
}

// ============ SETTINGS ============
async function loadSettings() {
    try {
        const response = await fetch(`${API_URL}/settings`);
        const settings = await response.json();
        
        document.getElementById('autoScan').checked = settings.autoScan;
        document.getElementById('scanInterval').value = settings.scanInterval;
        document.getElementById('defaultLimit').value = settings.defaultDataLimit;
        document.getElementById('notifyConnect').checked = settings.notifyOnConnect;
        document.getElementById('notifyDisconnect').checked = settings.notifyOnDisconnect;
        document.getElementById('notifyLimit').checked = settings.notifyOnLimit;
    } catch (error) {
        console.error('Error loading settings:', error);
    }
}

async function saveSettings() {
    const settings = {
        autoScan: document.getElementById('autoScan').checked,
        scanInterval: parseInt(document.getElementById('scanInterval').value) || 30,
        defaultDataLimit: parseFloat(document.getElementById('defaultLimit').value) || 5,
        notifyOnConnect: document.getElementById('notifyConnect').checked,
        notifyOnDisconnect: document.getElementById('notifyDisconnect').checked,
        notifyOnLimit: document.getElementById('notifyLimit').checked
    };
    
    try {
        const response = await fetch(`${API_URL}/settings`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(settings)
        });
        
        if (response.ok) {
            showToast('Pengaturan berhasil disimpan!');
        }
    } catch (error) {
        showToast('Gagal menyimpan pengaturan', 'error');
    }
}

async function changePassword() {
    const oldPassword = document.getElementById('oldPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    
    if (!oldPassword || !newPassword) {
        showToast('Isi semua field!', 'warning');
        return;
    }
    
    if (newPassword.length < 6) {
        showToast('Password minimal 6 karakter!', 'warning');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/auth/change-password`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ oldPassword, newPassword })
        });
        
        const data = await response.json();
        if (data.success) {
            showToast('Password berhasil diubah!');
            document.getElementById('oldPassword').value = '';
            document.getElementById('newPassword').value = '';
        } else {
            showToast(data.error || 'Gagal ubah password', 'error');
        }
    } catch (error) {
        showToast('Gagal ubah password', 'error');
    }
}

// ============ SCAN ============
async function manualScan() {
    const btn = document.querySelector('[onclick="manualScan()"]');
    const originalText = btn.innerHTML;
    btn.innerHTML = '<span class="material-icons">sync</span> Scanning...';
    btn.disabled = true;
    
    try {
        const response = await fetch(`${API_URL}/scan`, { method: 'POST' });
        const result = await response.json();
        
        if (result.success) {
            showToast(`Scan selesai! ${result.online || 0} device online`);
            await refreshDashboard();
            await fetchDevices();
        } else {
            showToast('Gagal scan', 'error');
        }
    } catch (error) {
        showToast('Gagal scan', 'error');
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
}

// ============ EXPORT ============
async function exportData() {
    try {
        const response = await fetch(`${API_URL}/export`);
        const data = await response.json();
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `hotspot_data_${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
        showToast('Data berhasil diekspor!');
    } catch (error) {
        showToast('Gagal ekspor data', 'error');
    }
}

// ============ CLEAR ALL ============
async function clearAllData() {
    if (!confirm('⚠️ Yakin ingin menghapus SEMUA data?')) return;
    if (!confirm('Konfirmasi lagi: Hapus semua data?')) return;
    
    try {
        await fetch(`${API_URL}/clear`, { method: 'POST' });
        showToast('Semua data dihapus!');
        refreshDashboard();
        fetchDevices();
        fetchLogs();
    } catch (error) {
        showToast('Gagal hapus data', 'error');
    }
}

// ============ CONNECTION STATUS ============
function updateConnectionStatus(isOnline) {
    const dot = document.getElementById('connectionStatus');
    dot.className = `status-dot ${isOnline ? 'online' : 'offline'}`;
}

// ============ AUTO UPDATE ============
function startAutoUpdate() {
    if (updateInterval) clearInterval(updateInterval);
    updateInterval = setInterval(() => {
        if (currentPage === 'dashboard') refreshDashboard();
        if (currentPage === 'devices') fetchDevices();
        if (currentPage === 'logs') fetchLogs();
    }, 5000);
}

// ============ INIT ============
async function init() {
    // Check auth
    await checkAuth();
    
    // Load dashboard
    await refreshDashboard();
    
    // Start auto update
    startAutoUpdate();
    
    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal.show').forEach(m => m.classList.remove('show'));
        }
        if (e.ctrlKey && e.key === 'r') {
            e.preventDefault();
            manualScan();
        }
    });
    
    // Visibility change - refresh when tab becomes visible
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
            if (currentPage === 'dashboard') refreshDashboard();
            if (currentPage === 'devices') fetchDevices();
            if (currentPage === 'logs') fetchLogs();
        }
    });
}

// ============ START ============
document.addEventListener('DOMContentLoaded', init);